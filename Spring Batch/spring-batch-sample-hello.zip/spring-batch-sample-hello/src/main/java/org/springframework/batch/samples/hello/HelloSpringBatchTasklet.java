/*
 * Copyright 2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.batch.samples.hello;

import java.util.Map.Entry;
import java.util.Set;

import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

/**
 *
 * @author Gunnar Hillert
 *
 */
public class HelloSpringBatchTasklet implements Tasklet {

	private static final String LINE = "------------------------------------------------";

	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {

		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();

		System.out.println("Hello Spring Batch!");

		if (jobParameters != null && !jobParameters.isEmpty()) {

			final Set<Entry<String, JobParameter>> parameterEntries = jobParameters.getParameters().entrySet();
			System.out.println(LINE);
			System.out.println(String.format("The following %s Job Parameter(s) is/are present:", parameterEntries.size()));
			System.out.println(LINE);
			for (Entry<String, JobParameter> jobParameterEntry : parameterEntries) {
				System.out.println(String.format(
						"Parameter name: %s; isIdentifying: %s; type: %s; value: %s",
						jobParameterEntry.getKey(),
						jobParameterEntry.getValue().isIdentifying(),
						jobParameterEntry.getValue().getType().toString(),
						jobParameterEntry.getValue().getValue()));
			}
			System.out.println(LINE);
		}
		return RepeatStatus.FINISHED;
	}
}