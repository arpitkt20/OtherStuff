/**
 *  Copyright (c) 2013-2014 Angelo ZERR.
 *  All rights reserved. This program and the accompanying materials
 *  are made available under the terms of the Eclipse Public License v1.0
 *  which accompanies this distribution, and is available at
 *  http://www.eclipse.org/legal/epl-v10.html
 *
 *  Contributors:
 *  Angelo Zerr <angelo.zerr@gmail.com> - initial API and implementation
 */
package org.eclipse.angularjs.core.utils;

public class AngularELRegion {

	private final String expression;
	private final int expressionOffset;

	public AngularELRegion(String expression, int expressionOffset) {
		this.expression = expression;
		this.expressionOffset = expressionOffset;
	}

	public String getExpression() {
		return expression;
	}

	public int getExpressionOffset() {
		return expressionOffset;
	}

}
