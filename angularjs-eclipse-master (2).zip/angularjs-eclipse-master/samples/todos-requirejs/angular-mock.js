define(function() {
	return angular;
});