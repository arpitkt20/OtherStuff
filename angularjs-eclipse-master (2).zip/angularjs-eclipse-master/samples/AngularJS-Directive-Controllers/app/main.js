(function( ng ) {

	"use strict";

	// Define our AngularJS application module.
	window.demo = ng.module( "Demo", [] );

})( angular );