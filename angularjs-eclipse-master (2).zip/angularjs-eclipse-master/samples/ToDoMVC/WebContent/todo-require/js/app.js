/*global define*/
'use strict';

define(['angular'], function (angular) {
	return angular.module('todomvc', []);
});
