package org.eclipse.angularjs.internal.ui.viewers;

public class AngularOutlineLabelProviderOLD extends AngularElementLabelProvider {

}
