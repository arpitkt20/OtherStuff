(function(){
	var app = angular.module('store',[]);
	
	app.controller('StoreController',function(){
		this.product = gem;
	});
	
	var gem = {
		name:	'GemName',
		price:	2.95,
		description: 'gem description',
		canPurchase: true,
		soldOut: false
	}
	
})();