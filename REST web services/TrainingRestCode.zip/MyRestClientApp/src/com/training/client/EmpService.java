package com.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

public class EmpService {

	public Response connect(String url,String mediaType){
		Client client=ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget webTarget=client.target(url);
		Invocation.Builder inv=webTarget.request(mediaType);
		Response response=inv.get(); // here the get operation is invoked
		return response;
	}
	
	
	public void getAllEmpInXML(){
		String url="http://localhost:8080/restfulapp/webapi/empservice/employees";
		String mediaType="application/xml";
		Response response=connect(url, mediaType);
		if(response.getStatus()!=200){
			throw new RuntimeException("Failed ");
		}else{
			String output=response.readEntity(String.class);
			System.out.println(output);
			
		}
	}
	
	public void getAllEmpInJson(){
		String url="http://localhost:8080/restfulapp/webapi/empservice/json/employees";
		String mediaType="application/json";
		Response response=connect(url, mediaType);
		if(response.getStatus()!=200){
			throw new RuntimeException("Failed ");
		}else{
			String output=response.readEntity(String.class);
			System.out.println(output);
			
		}
	}
	
}
