package com.training.client;

public class Test {

	public static void main(String[] args) {
		EmpService es=new EmpService();
		//es.getAllEmpInXML();
		es.getAllEmpInJson();
	}
}
