package com.rest.training.restfulapp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.rest.training.restfulapp.model.Employee;

@Path("/empservice")
public class EmployeeService {
	
	private static Map<String,Employee> employees=new HashMap<String,Employee>();
	
	static{
		Employee e1=new Employee();
		e1.setEmployeeId("101");
		e1.setEmployeeName("Ravish");
		e1.setSalary(23456);
		
		employees.put(e1.getEmployeeId(), e1);
		
		Employee e2=new Employee();
		e2.setEmployeeId("102");
		e2.setEmployeeName("Sunita");
		e2.setSalary(45678);
		
		employees.put(e2.getEmployeeId(), e2);
		
	}
	
	@GET
	@Path("/employees")
	@Produces("application/xml")
	public List<Employee> listEmployees(){
		return new ArrayList<Employee>(employees.values());
	}
	
	@GET
	@Path("/employees/{employeeid}")
	@Produces("application/xml")
	public Employee getEmployee(@PathParam("employeeid") String employeeid){
		return employees.get(employeeid);
	}
	
	@GET
	@Path("/json/employees")
	@Produces("application/json")
	public List<Employee> listEmployeesInJson(){
		return new ArrayList<Employee>(employees.values());
	}	
	
	@GET
	@Path("/json/employees/{employeeid}")
	@Produces("application/json")
	public Employee getEmployeeInJson(@PathParam("employeeid") String employeeid){
		return employees.get(employeeid);
	}	
	
}
