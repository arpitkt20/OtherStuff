package com.rest.training.restfulapp.service;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rest.training.restfulapp.model.Task;
import com.rest.training.restfulapp.model.TaskDAO;

@Path("/tasks")
public class TaskService {

	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Task> listTasks(){
		List<Task> ls=new ArrayList<Task>();
		ls.addAll(TaskDAO.getModel().values());
		return ls;
	}
	
	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateTaskByID(@PathParam("id") String id,Task t){
		Task temp=new Task();
		temp.setId(id);
		temp.setDescription(t.getDescription());
		TaskDAO.getModel().put(id, temp);
		return Response.ok().entity(temp).build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	//@Produces(MediaType.TEXT_HTML)
	public void newTask(@FormParam("id") String id,@FormParam("description") String description){
		Task temp=new Task();
		temp.setId(id);
		temp.setDescription(description);
		TaskDAO.getModel().put(id, temp);
	}

	
	
	
	
	
	
	
	
	
	
}
