package com.rest.training.restfulapp.model;

import java.util.HashMap;
import java.util.Map;

public class TaskDAO {

	private static Map<String,Task> LOOKUP_DATA=new HashMap<String,Task>();
	
	static{
		Task task1=new Task();
		task1.setId("T1");
		task1.setDescription("Review Documents");
		
		Task task2=new Task();
		task2.setId("T2");
		task2.setDescription("Review Test Cases");
	
		LOOKUP_DATA.put(task1.getId(), task1);
		LOOKUP_DATA.put(task2.getId(), task2);
		
	}
	
	public static Map<String,Task> getModel(){
		return LOOKUP_DATA;
	}
}
